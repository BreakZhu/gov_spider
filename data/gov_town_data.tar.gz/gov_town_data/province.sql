/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : code_spider

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 17/12/2018 10:37:37
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for province
-- ----------------------------
DROP TABLE IF EXISTS `province`;
CREATE TABLE `province`  (
  `province_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '省份名',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 68 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of province
-- ----------------------------
INSERT INTO `province` VALUES ('北京市', 36);
INSERT INTO `province` VALUES ('天津市', 37);
INSERT INTO `province` VALUES ('河北省', 38);
INSERT INTO `province` VALUES ('山西省', 39);
INSERT INTO `province` VALUES ('内蒙古自治区', 40);
INSERT INTO `province` VALUES ('辽宁省', 41);
INSERT INTO `province` VALUES ('吉林省', 42);
INSERT INTO `province` VALUES ('黑龙江省', 43);
INSERT INTO `province` VALUES ('上海市', 44);
INSERT INTO `province` VALUES ('江苏省', 45);
INSERT INTO `province` VALUES ('浙江省', 46);
INSERT INTO `province` VALUES ('安徽省', 47);
INSERT INTO `province` VALUES ('福建省', 49);
INSERT INTO `province` VALUES ('江西省', 50);
INSERT INTO `province` VALUES ('山东省', 51);
INSERT INTO `province` VALUES ('河南省', 52);
INSERT INTO `province` VALUES ('湖北省', 53);
INSERT INTO `province` VALUES ('湖南省', 54);
INSERT INTO `province` VALUES ('广东省', 55);
INSERT INTO `province` VALUES ('广西壮族自治区', 56);
INSERT INTO `province` VALUES ('海南省', 57);
INSERT INTO `province` VALUES ('重庆市', 58);
INSERT INTO `province` VALUES ('四川省', 59);
INSERT INTO `province` VALUES ('贵州省', 60);
INSERT INTO `province` VALUES ('云南省', 61);
INSERT INTO `province` VALUES ('西藏自治区', 62);
INSERT INTO `province` VALUES ('陕西省', 63);
INSERT INTO `province` VALUES ('甘肃省', 64);
INSERT INTO `province` VALUES ('青海省', 65);
INSERT INTO `province` VALUES ('宁夏回族自治区', 66);
INSERT INTO `province` VALUES ('新疆维吾尔自治区', 67);

SET FOREIGN_KEY_CHECKS = 1;
